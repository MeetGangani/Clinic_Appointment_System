import React from 'react'

function AboutDoctor() {
  return (
    <div>
      Doctor Info
    </div>
  )
}

export default AboutDoctor
