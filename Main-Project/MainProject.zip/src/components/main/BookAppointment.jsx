import React, { useState } from 'react'
// import DatePicker from "react-datepicker";
import { DatePicker, Stack } from 'rsuite';
import { FaCalendar, FaClock } from 'react-icons/fa';
import { BsCalendar2MonthFill } from 'react-icons/bs';
function BookAppointment() {
  const [startDate, setStartDate] = useState(new Date());

  return (
    <div >
      <label htmlFor="">Choose date for Treatment</label>
      <Stack spacing={10} direction="column" alignItems="flex-start">
    <DatePicker format="MM/dd/yyyy" />
  </Stack>

    </div>
  )
}

export default BookAppointment
