import React from 'react'

function Home() {
  return (
    <div className='flex h-[665px] meet text-center '>
        <div >
        <img className=' h-[665px] rounded-xl border-4 border-gray-400' src="https://thumbs.dreamstime.com/b/welcome-to-our-clinic-smiling-doctor-opens-his-hands-flat-cartoon-style-design-vector-illustration-white-background-183747924.jpg" alt="" />
        </div>

        
        <div className=" w-96 max-h-full mx-auto my-auto ">
            <div><p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur aperiam est commodi ipsa eius omnis totam aut, itaque, repudiandae quaerat eaque, hic provident beatae ut possimus error veritatis sit doloremque facere neque. Praesentium tenetur adipisci molestias obcaecati magnam, illo alias officia nihil autem eum exercitationem incidunt pariatur sed consequatur magni velit explicabo suscipit sit repellat in fugit maxime voluptatum accusantium. Vitae odit quasi soluta enim, sunt, omnis magni eos laudantium dolores dolore explicabo minus voluptas ipsum consectetur illo quos sequi blanditiis doloremque asperiores maiores corporis aut nemo hic libero. Consectetur voluptatem quasi corrupti, in repellat voluptates! Aliquid.</p>
            </div>
            <button className=' my-4 border-2 rounded-md  cursor-pointer bg-MintGreen px-5 py-2 font-bold '>Book Appointment</button>
        </div>        
    </div>
    )
}

export default Home

