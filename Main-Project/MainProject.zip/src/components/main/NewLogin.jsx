import React from 'react'

function NewLogin() {
  return (
    <div class="  bg-LoginBack w-[400px] h-[450px] flex justify-center items-center  rounded-[15px] border-2 border-solid border-[rgba(255,0,0,0.349)] ">
    <form action="">
      <h2>Login</h2>

      <div class="input-box">
        <span class="icon">
          <ion-icon name="mail"></ion-icon>
        </span>
        <input type="email" required />
        <label>Email</label>
      </div>

      <div class="input-box">
        <span class="icon">
          <ion-icon name="lock-closed"></ion-icon>
        </span>
        <input type="password" required />
        <label>Password</label>
      </div>

      <div class="remember-forgot">
        <label><input type="checkbox" /> Remember me</label>
        <a href="#">Forgot Password?</a>
      </div>

      <button type="submit">Login</button>

      <div class="register-link">
        <p>Don't have an account? <a href="#">Register</a></p>
      </div>
    </form>
  </div>
  )
}

export default NewLogin
