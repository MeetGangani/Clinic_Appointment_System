import React from 'react'

function Medicines() {
  return (
    <div>
      Medicines
    </div>
  )
}

export default Medicines
