import React from 'react'

function Seperator() {
  return (
    <div className=' h-1 bg-DimGray'>
      
    </div>
  )
}

export default Seperator
